/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package DrugStore;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import drugstore.pack.Work2Remote;

public class DrugstoreTester {

	public static void main(String[] args) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			//set the app-server properties
			Properties env = new Properties(); 
			env.setProperty("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory"); 
			env.setProperty("java.naming.provider.url", "localhost:1099"); 
			env.setProperty("java.naming.factory.url.pkgs", "org.jboss.naming"); 
			
			
			//connect
			Context context =new InitialContext(env);
			Work2Remote m2 = (Work2Remote)context.lookup("Work2/remote");
			//drugstore
			System.out.println("****************** DrugStore #1609 ********************");
		
				int option=0;
				do{
					System.out.println("\nPlease type the required option:");
					System.out.println("1. Check Prescription To Complete");
					System.out.println("2. Drug Info");
					System.out.println("3. Any Other Key To Exit!");
					System.out.print("Option: ");
					option = Integer.parseInt(br.readLine());
					switch(option){
						case 1:
							// check Prescription to complete
							String p = recievePrescription();
							if(p!=null){
								System.out.println(p);
								do{
									System.out.println("Press 1 when to send Ack to Doctor");
									int num1 = Integer.parseInt(br.readLine());
									switch(num1){
										case 1:
											sendAck("Prescription Completed!");
											break;
										default:
											break;
									}
								}while(option!=1);
							}else{
								System.out.println("There Is No Prescription To Complete!");
							}
							break;
						case 2:
							//Drug info
							System.out.print("Enter Drug Name:");
							String name=br.readLine().toUpperCase();
							System.out.println(m2.queryDrug(name));
							break;
						default:
							break;
					}
				}while(option<3);
			System.out.println("System Closed! Please Close The Program!");
		} 
		catch (NamingException e) {
			e.printStackTrace();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	
	
	//send ack to doctor
	public static void sendAck(String ack) {
		if(ack!=null){
			try{
				InitialContext conetxt=new InitialContext();
				ConnectionFactory factory=(ConnectionFactory)conetxt.lookup("ConnectionFactory");	
				QueueConnection qc=(QueueConnection)factory.createConnection();
				QueueSession qss=(QueueSession)qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
				Queue q=null;
				q=(Queue)conetxt.lookup("queue/Ack");
				if (q==null)
					q=(Queue)qss.createQueue("queue/Ack");
				qc.start();
				QueueSender quSend=qss.createSender(q);
				TextMessage tm = qss.createTextMessage();
				tm.setText(ack);
				quSend.send(tm);
				qss.close();
				qc.close();
			}
			catch (NamingException e){
				e.printStackTrace();
			}
			catch (JMSException e){
				e.printStackTrace();
			}
			System.out.println("Ack Sent To Doctor!");
		}else{
			System.out.println("There Is No Ack To Send!");
		}
	}
	//recieve prescription from doctor
	public static String recievePrescription() {
		try{
			InitialContext conetxt=new InitialContext();
			ConnectionFactory factory=(ConnectionFactory)conetxt.lookup("ConnectionFactory");	
			QueueConnection qc=(QueueConnection)factory.createConnection();
			QueueSession qss=(QueueSession)qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			Queue q=null;
			q=(Queue)conetxt.lookup("queue/Prescription");
			if (q==null)
				q=(Queue)qss.createQueue("queue/Prescription");
			qc.start();
			//recieve prescription
			QueueReceiver quRec=qss.createReceiver(q);
			ObjectMessage om =(ObjectMessage)quRec.receive(3000);
			qss.close();
			qc.close();
			if(om!=null)
				return (String)om.getObject();
		}
		catch (NamingException e){
			e.printStackTrace();
		}
		catch (JMSException e){
			e.printStackTrace();
		}
		return null;
	}
	
	
}


