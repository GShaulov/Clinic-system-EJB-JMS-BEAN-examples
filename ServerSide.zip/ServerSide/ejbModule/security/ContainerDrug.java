/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;

import java.util.ArrayList;
//list manager of drugs
public class ContainerDrug {
	//variables
	private ArrayList<Drug> drugs;
	
	//constructor
	public ContainerDrug(){
		this.drugs = new ArrayList<Drug>();
		//example
		addDrug("1111", "ACAMOL", "ACAMOL INFO", 24, 3);
		addDrug("2222", "NUROFEN", "NUROFEN INFO", 10, 2);
		addDrug("3333", "RITALIN", "RITALIN INFO", 100, 1);
		addDrug("4444", "TAMIFLU", "TAMIFLU INFO", 10, 1);
		addDrug("5555", "ASPIRIN", "ASPIRIN INFO", 20, 2);
	}
	
	//add drug
	public void addDrug(String sku, String name, String info, int quantity, int dosePerDay) {
		Drug drug = new Drug(sku, name, info, quantity, dosePerDay);
		drugs.add(drug);
	}
	
	//remove drug
	public void removeDrug(String name){
		for(int i=0; i<drugs.size(); i++)
			if(drugs.get(i).getName().equals(name))
					drugs.remove(i);
	}
	//get info about specific drug
	public String queryDrug(String name){
		for(int i=0; i<drugs.size(); i++)
			if(drugs.get(i).getName().equals(name))
					return drugs.get(i).toString();
		return null;
	}
	//find drug by name
	public Drug findDrugByName(String name){
		Drug drug=null;
		for(int i=0; i<drugs.size(); i++)
			if(drugs.get(i).getName().equals(name))
					drug = drugs.get(i);
		if(drug==null)
			drug = new Drug(null,name,name+" Info",0,0);
		return drug;
	}
	
}
