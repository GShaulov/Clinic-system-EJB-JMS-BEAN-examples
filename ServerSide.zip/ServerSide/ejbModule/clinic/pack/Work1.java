/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */

package clinic.pack;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;

import security.ContainerDrug;
import security.LogIn;
import security.Prescription;
import security.Visit;

@Stateful
@LocalBean
public class Work1 implements Work1Remote {
	//variables
	private Visit visit=null;
	private Prescription prescription = null;
	private boolean isSaved=false;
 	//constructor
	public Work1() {
    	visit = new Visit();
    	prescription = new Prescription();
    }
	//כניסה למערכת
	@Override
	public boolean logIn(String id, String password){
		LogIn lg = new LogIn();
		visit = lg.access(id, password);
		if(visit==null)
			return false;
		else
			return true;
	}
	//הרופא מקליד ת.ז ושם של הפציינט.
	@Override
	public boolean setPatient(String patientID, String patientName) {
		if(!patientID.equals("") && patientID!=null){
			visit.setPatient(patientID, patientName);
			return true;
		}else
			return false;
	}
	//הרופא מתאר את האבחנה
	@Override
	public String addDistinction(String distinction) {
		if(visit.getPatient()!=null && !isSaved)
			return visit.getPatient().addDistinction(distinction);
		else
			return "There is no Patient was added!";
	}
	// הרופא יכול ליצור מרשם.
	@Override
	public String createPrescription() {
			prescription = new Prescription();
			prescription.setDoctorID(visit.getDoctor().getId());
			prescription.setPatientID(visit.getPatient().getId());
			return "Prescription Created!";	
	}
	// הרופא יכול להוסיף תרופה למרשם
	@Override
	public String addDrug(String name) {
		if(prescription!=null){
			ContainerDrug c = new ContainerDrug();
			prescription.AddDrug(c.findDrugByName(name));
			return name + " Was Added!";
		}
		else
			return "There is no prescription added!";
	}
	//  ושומר אותו הרופא מוסיף את המרשם לפציינט
	@Override
	public String savePrescription() {
		if(prescription!=null){
			visit.getPatient().addPrescriptions(prescription);
			isSaved=true;
			return "Prescription Saved!\n"+visit.toString();
		}		
		else
			return "There is no prescription added!";
		
	}
	//  מחזיר מרשם כמחרוזת כדי לשלוח לבית מרקחת
	@Override
	public String getPrescription() {
		if(this.prescription.getDrugs().size()>0)
			return this.prescription.toString();
		else
			return null;
	}

}
