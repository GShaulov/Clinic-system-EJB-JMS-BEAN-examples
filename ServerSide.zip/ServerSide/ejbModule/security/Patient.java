/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;

import java.util.ArrayList;

public class Patient {
	//variables
	private String id;
	private String name;
	private String phone;
	private ArrayList<String> distinction;
	private ArrayList<Prescription> prescriptions;
	
	//constructor
	Patient(String id, String name, String phone){
		this.id=id;
		this.name=name;
		this.phone=phone;
		this.distinction = new ArrayList<String>();
		this.prescriptions = new ArrayList<Prescription>();
	}
	//getters and setters
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	//return all history of patient destinctions
	public String getDistinction() {
		String str ="";
		for (int i=0; i<distinction.size(); i++)
			str += distinction.get(i)+"\n";
		return str;
	}
	
	//add new distinction
	public String addDistinction(String str) {
		this.distinction.add(0, str);
		return "Distinction Added!"; 
	}
	
	//remove specific distinction
	public String removeLastDistinction() {
		if(this.distinction!=null&&this.distinction.size()>0){
			this.distinction.remove(0);
			return "Distinction Removed!";
		}else
			return "There is no distinction was added!";
		
	}
	//getprescription
	public ArrayList<Prescription> getPrescriptions() {
		return prescriptions;
	}
	//add prescription
	public void addPrescriptions(Prescription prescriptions) {
		this.prescriptions.add(prescriptions);
	}
	//remove prescription
	public void removePrescriptions(Prescription prescriptions) {
		this.prescriptions.remove(prescriptions);
	}
	//toString
	@Override
	public String toString() {
		return "Patient ID: " + id + "\tName: " + name + "\tPhone: " + phone + "\nDistinction: " + distinction + "\n" + "\nPrescriptions: " + prescriptions;
	}

	
}
