/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package ClinicTester;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import clinic.pack.Work1Remote;
import drugstore.pack.Work2Remote;

public class ClinicTester {
	public static void main(String[] args) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			//set the app-server properties
			Properties env = new Properties(); 
			env.setProperty("java.naming.factory.initial", "org.jnp.interfaces.NamingContextFactory"); 
			env.setProperty("java.naming.provider.url", "localhost:1099"); 
			env.setProperty("java.naming.factory.url.pkgs", "org.jboss.naming"); 
			
			
			//connect
			Context context =new InitialContext(env);
			Work1Remote m = (Work1Remote)context.lookup("Work1/remote");
			Work2Remote m2 = (Work2Remote)context.lookup("Work2/remote");
			//get doctor logIn
			System.out.println("******************Please LogIn: ********************");
			System.out.print("Enter Doctor ID:");
			String doctorID=br.readLine();
			System.out.print("Enter Doctor Password:");
			String password=br.readLine();
			//logIn
			if(m.logIn(doctorID, password)){
				//setPatient
				boolean isPatient=false;
				do{
					System.out.print("Enter Patient ID:");
					String patientID=br.readLine();
					System.out.print("Enter Patient Name:");
					String patientName=br.readLine();
					if(m.setPatient(patientID, patientName))
						isPatient=true;
					else
						System.err.println("Wrong Input!");
				}while(!isPatient);

				//set Distinction
				System.out.print("Add Distinction:");
				String distinction=br.readLine();
				System.out.println(m.addDistinction(distinction));
				
				int option=0;
				do{
					System.out.println("\nPlease type the required option:");
					System.out.println("1. Create Prescription");
					System.out.println("2. Drug Info");
					System.out.println("3. Add Distinction");
					System.out.println("4. Add Drug To Prescription");
					System.out.println("5. Add Prescription To Patient and Save");
					System.out.println("6. Exit!");
					System.out.print("Option: ");
					option = Integer.parseInt(br.readLine());
					switch(option){
						case 1:
							System.out.println(m.createPrescription());
							break;
						case 2:
							//Drug info
							System.out.print("Enter Drug Name:");
							String name=br.readLine().toUpperCase();
							System.out.println(m2.queryDrug(name));
							break;
						case 3:
							//set Distinction
							System.out.print("Add Distinction:");
							distinction=br.readLine();
							System.out.println(m.addDistinction(distinction));
							break;
						case 4:
							//Add Drug To Prescription
							System.out.print("Enter Drug Name:");
							String drugName=br.readLine().toUpperCase();
							System.out.println(m.addDrug(drugName));
							break;
						case 5:
							// Add Prescription To Patient and Save
							System.out.println(m.savePrescription());
							
							System.out.println("Press 1 to send Prescription to Drugstore or any other key to Exit!");
							int num1 = Integer.parseInt(br.readLine());
							switch(num1){
								case 1:
									sendPrescription(m.getPrescription());
									System.out.println("Press 1 to check Prescription Ack or any other key to Exit!");
									int num2 = Integer.parseInt(br.readLine());
									switch(num2){
										case 1:
											String ack = recieveAck();
											if(ack!=null)
												System.out.println("Recieved: "+ ack);
											else
												System.out.println("There Is No Prescription Acks To Recieve!");
											break;
										default:
											break;
									}
									break;
								default:
									break;
							}
							break;
						default:
							break;
					}
				}while(option<5);
			}else{
				System.out.println("Wrong ID or Password!");
			}
			System.out.println("System Closed! Please Close The Program!");
		} 
		catch (NamingException e) {
			e.printStackTrace();
		}
		catch (Exception e){
			e.printStackTrace();
		}
	}
	
	
	//send prescription for drugstore
	public static void sendPrescription(String prescription ) {
		if(prescription !=null){
			try{
				InitialContext conetxt=new InitialContext();
				ConnectionFactory factory=(ConnectionFactory)conetxt.lookup("ConnectionFactory");	
				QueueConnection qc=(QueueConnection)factory.createConnection();
				QueueSession qss=(QueueSession)qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
				Queue q=null;
				q=(Queue)conetxt.lookup("queue/Prescription");
				if (q==null)
					q=(Queue)qss.createQueue("queue/Prescription");
				qc.start();
				QueueSender quSend=qss.createSender(q);
				ObjectMessage om = qss.createObjectMessage(prescription);
				quSend.send(om);
				qss.close();
				qc.close();
			}
			catch (NamingException e){
				e.printStackTrace();
			}
			catch (JMSException e){
				e.printStackTrace();
			}
			System.out.println("Prescription Sent To Drugstore!");
		}else{
			System.out.println("No Prescription To Send!");
		}
	}

	//recieve ack from drugstore
	public static String recieveAck() {
		try{
			InitialContext conetxt=new InitialContext();
			ConnectionFactory factory=(ConnectionFactory)conetxt.lookup("ConnectionFactory");	
			QueueConnection qc=(QueueConnection)factory.createConnection();
			QueueSession qss=(QueueSession)qc.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			Queue q=null;
			q=(Queue)conetxt.lookup("queue/Ack");
			if (q==null)
				q=(Queue)qss.createQueue("queue/Ack");
			qc.start();
			
			//recieve ack
			QueueReceiver quRec=qss.createReceiver(q);
			TextMessage tm=(TextMessage)quRec.receive();
			qss.close();
			qc.close();
			if(tm!=null)
				return tm.getText();
		}
		catch (NamingException e){
			e.printStackTrace();
		}
		catch (JMSException e){
			e.printStackTrace();
		}
		return null;
	}
	
	
}


