/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;

import java.util.ArrayList;
import java.util.HashMap;

//list manager of Doctor
public class ContainerDoctor {
	//variables
	private ArrayList<Doctor> doctors;
	private HashMap<String, Doctor> hm;
	
	//constructor
	public ContainerDoctor(){
		this.doctors = new ArrayList<Doctor>();
		this.hm = new HashMap<String, Doctor>();
		addDoctor("317572386", "Dr. Grigory Shaulov", "0509050965", "123456");
	}
	//add doctor
	public void addDoctor(String id, String name, String phone, String password) {
		Doctor doctor = new Doctor(id, name, phone, password);
		doctors.add(doctor);
		hm.put(id, doctor);
	}
	//remove doctor
	public void removeDoctor(String id) {
		Doctor doctor = hm.get(id);
		doctors.remove(doctor);
		hm.remove(id);
	}
	//check doctor id and password to create new visit
	public Visit access(String id, String password){
		Doctor doctor = hm.get(id);
		if( doctor==null || password==null || password.equals("") )
			return null;
		if(doctor.getPassword().equals(password)){
			return new Visit(doctor);
		}
		else
			return null;
	}
	
}
