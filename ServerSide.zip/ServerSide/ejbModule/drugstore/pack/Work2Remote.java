/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package drugstore.pack;

import javax.ejb.Remote;

@Remote
public interface Work2Remote {
	//הרופא יכול לבדוק תרופה ולקבל מידע עליו
	public String queryDrug(String name);
}
