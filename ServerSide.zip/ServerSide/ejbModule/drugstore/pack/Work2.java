/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package drugstore.pack;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import security.ContainerDrug;

@Stateless
@LocalBean
public class Work2 implements Work2Remote {
	//cunstructor
    public Work2() {  }
	//הרופא יכול לבדוק תרופה ולקבל מידע עליו
    @Override
	public String queryDrug(String name) {
		ContainerDrug cd = new ContainerDrug();
		return cd.queryDrug(name);
	}
}
