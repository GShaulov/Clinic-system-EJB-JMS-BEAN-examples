/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;

public class Visit {
	//variables
	private static long idGenerator=0;
	private String id;
	private Doctor doctor;
	private Patient patient;
	
	//constructor
	public Visit() {	}
	//constructor
	public Visit(Doctor doctor) {
		this.id = "" + (++idGenerator);
		this.doctor=doctor;
	}
	//getters and setters
	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(String id, String name) {
			patient = new Patient(id, name, null);
	}

	public String getId() {
		return id;
	}
	//toString
	@Override
	public String toString() {
		return String.format("\n********** Visit No: %s :**********\n%s\n%s", id, doctor, patient);
	}



	


}
