/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.ListIterator;

//מרשם
public class Prescription implements Serializable{
	//variables
	private static final long serialVersionUID = 1L;
	private static long idGenerator=0;
	private String id;
	private String doctorID;
	private String patientID;
	private ArrayList<Drug> drugs;
	//constructor
	public Prescription(){
		this.id = "" + (++idGenerator);
		this.drugs=new ArrayList<Drug>();
	}
	//return seved prescription as string
	public String savePrescription(){
		String str = String.format("****************** Prescription Info ********************\nDoctorID: %s\nPatientID: %s\nDr", doctorID, patientID);
		str += "Drugs:\nName \tQuantity \tdosePerDay\n";
		ListIterator<Drug> it=drugs.listIterator();
		while(it.hasNext()){
			Drug drug = it.next();
			str += String.format("%s\t%s\t%s\t",drug.getName(), drug.getQuantity(), drug.getDosePerDay());
		}
		return str;
	}
	//getters and setters
	public String getDoctorID() {
		return doctorID;
	}

	public void setDoctorID(String doctorID) {
		this.doctorID = doctorID;
	}

	public String getPatientID() {
		return patientID;
	}

	public void setPatientID(String patientID) {
		this.patientID = patientID;
	}

	public ArrayList<Drug> getDrugs() {
		return drugs;
	}

	public void AddDrug(Drug drug) {
		this.drugs.add(drug);
	}
	
	public void removeDrug(Drug drug) {
		this.drugs.remove(drug);
	}
	
	public String getId() {
		return id;
	}

	//toString
	@Override
	public String toString() {
		return "ID: " + id + "\tDoctor ID: " + doctorID + "\tPatient ID: " + patientID + "\n" + drugs;
	}


	
	
}