/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package clinic.pack;

import javax.ejb.Remote;


@Remote
public interface Work1Remote {
	//כניסה למערכת
	public boolean logIn(String doctorID, String password);
	//הרופא מקליד ת.ז ושם של הפציינט.
	public boolean setPatient(String patientID,String patientName);
	//הרופא מתאר את האבחנה
	public String addDistinction(String distinction);
	// הרופא יכול ליצור מרשם.
	public String createPrescription();
	// הרופא יכול להוסיף תרופה למרשם
	public String addDrug(String name);	
	//  ושומר אותו הרופא מוסיף את המרשם לפציינט
	public String savePrescription();
	//  מחזיר מרשם כמחרוזת כדי לשלוח לבית מרקחת
	public String getPrescription();


}
