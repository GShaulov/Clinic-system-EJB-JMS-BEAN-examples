/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;

public class LogIn {
	//constructor
	public LogIn(){	}
	//try to login and create new visit
	public Visit access(String id, String password){
		ContainerDoctor cd = new ContainerDoctor();
		return cd.access(id, password);
	}
}
