/*
 * Grigory Shaulov 317572386
 * Shirel Stoler 324533629
 * Shlomi Shemesh 040782393
 */
package security;

import java.io.Serializable;

public class Drug implements Serializable{
	//variables
	private static final long serialVersionUID = 1L;
	private String sku;
	private String name;
	private String info;
	private int quantity;
	private int dosePerDay;
	
	//constructor
	public Drug() {	}
	//constructor
	public Drug(String sku, String name, String info, int quantity, int dosePerDay) {
		super();
		this.sku = sku;
		this.name = name;
		this.info = info;
		this.quantity = quantity;
		this.dosePerDay = dosePerDay;
	}
	
	//getters and setters
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String drugInfo) {
		this.info = drugInfo;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getDosePerDay() {
		return dosePerDay;
	}
	public void setDosePerDay(int dosePerDay) {
		this.dosePerDay = dosePerDay;
	}
	//toString
	@Override
	public String toString() {
		return String.format("********** Drug Information ***********\nName: %s\nSKU: %s\nQuantity: %d\nDose Per Day: %d\nInfo: %s\n\n" , name, sku, quantity, dosePerDay, info);
	}
	
	
}
